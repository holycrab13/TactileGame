﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TactileDoor : TactileObject {

    public string target;

    public int targetX;

    public int targetY;

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisplaySettings : MonoBehaviour {

    public float tileSize;

    public Material spriteMaterial;
}

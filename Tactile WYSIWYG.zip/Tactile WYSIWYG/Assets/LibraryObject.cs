﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LibraryObject : MonoBehaviour {

    public string id;

    public string label;

    public string description;

    public Sprite image;

    public bool block;


}
